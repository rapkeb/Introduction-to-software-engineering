
# milestone-3-team-35-316418391_315309666_207487828
in order for the program to run please go into the app.cinfig file and change the line -
      <param name="File" value="C:\\Users\\Eilon\\source\\repos\\KanbanSolution\\KanbanProject\\KanbanProjectLogger.log"/>

