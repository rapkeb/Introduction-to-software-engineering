﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace KanbanProjectTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_RegisterMethod1()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", "null");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod2()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", null);
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod3()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", "254");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod4()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", "barak123456789Barak01");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod5()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", "barak123");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod6()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", "ADGJL1");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod7()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", "Barak");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod8()
        {
            Boolean current = KanbanProject.Mainframe.Register("barak", "Bb123");
            Assert.AreEqual(current, true);
        }
        [TestMethod]
        public void Test_RegisterMethod9()
        {
            Boolean current = KanbanProject.Mainframe.Register("John", "Barak123789456BbBbBb");
            Assert.AreEqual(current, true);
        }
        [TestMethod]
        public void Test_RegisterMethod10()
        {
            Boolean current = KanbanProject.Mainframe.Register("null", "Bb123");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod11()
        {
            Boolean current = KanbanProject.Mainframe.Register(null, "aA543");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod12()
        {
            KanbanProject.Mainframe.Register("Barak", "Bb123");
            Boolean current = KanbanProject.Mainframe.Register("barak", "Thj345");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod13()
        {
            KanbanProject.Mainframe.Register("Noam", "dA290");
            Boolean current = KanbanProject.Mainframe.Register("Noam", "Johni12");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod14()
        {
            KanbanProject.Mainframe.Register("barak", "Trx765");
            Boolean current = KanbanProject.Mainframe.Register("Barak", "Bb123");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_RegisterMethod15()
        {
            Boolean current = KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            Assert.AreEqual(current, true);
        }
        [TestMethod]
        public void Test_AddTaskMethod1()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask("", "", "28/07/2019");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_AddTaskMethod2()
        {
            KanbanProject.Mainframe.Register("Dvir", "Dvir123");
            KanbanProject.Mainframe.Login("Dvir", "Dvir123");
            KanbanProject.Mainframe.AddBoard("Work");
            KanbanProject.Mainframe.ChooseBoard("Work");
            Boolean current = KanbanProject.Mainframe.AddTask("Bring milk", "3% fat", "21/07/2019");
            Assert.AreEqual(current, true);
        }
        [TestMethod]
        public void Test_AddTaskMethod3()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask("I need to bring milk home, I dont know if I can do it, it is to hard for me today, I'm really tired", "", "28/07/2019");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_AddTaskMethod4()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask("Milk", "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd" +
                "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd" +
                "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd" +
                "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd", "28/07/2019");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_AddTaskMethod5()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Work");
            KanbanProject.Mainframe.ChooseBoard("Work");
            Boolean current = KanbanProject.Mainframe.AddTask("Finish homework", "today", "28/07/2019");
            Assert.AreEqual(current, true);
        }
        [TestMethod]
        public void Test_AddTaskMethod6()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask("I need to bring milk home", "5% fat", "22/05/2019");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_AddTaskMethod7()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask(null, "Immediately", "28/07/2019");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_AddTaskMethod8()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask("Test", "null", "28/07/2019");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_AddTaskMethod9()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            KanbanProject.Mainframe.ChooseBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask("Buy bread", "2 pieces", "15/06/2019");
            Assert.AreEqual(current, false);
        }
        [TestMethod]
        public void Test_AddTaskMethod10()
        {
            KanbanProject.Mainframe.Register("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.Login("Guy@gmail.com", "Guy444");
            KanbanProject.Mainframe.AddBoard("Home");
            Boolean current = KanbanProject.Mainframe.AddTask("Computer", "take him to lab", "hfksirbfjd");
            Assert.AreEqual(current, false);
        }
    }
}
